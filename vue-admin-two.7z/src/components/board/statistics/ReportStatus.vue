<template lang="">
    <div>
        <Sidebar/>
        <br/>   
        <h2>고장 리포트 통계</h2>
    </div>
</template>
<script>
import Sidebar from '../../common/SideBar'

export default {
    name: "ReportStatus",
    components:{
        Sidebar
    }
}
</script>
<style lang="">
    
</style>