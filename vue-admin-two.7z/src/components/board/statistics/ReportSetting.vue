<template lang="">
    <div>
        <Sidebar/>
        <br/>   
        <h2>리포트 설정</h2>
    </div>
</template>
<script>
import Sidebar from '../../common/SideBar'

export default {
    name: "ReportSetting",
    components:{
        Sidebar
    }
}
</script>
<style lang="">
    
</style>