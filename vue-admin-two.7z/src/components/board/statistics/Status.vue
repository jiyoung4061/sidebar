<template lang="">
    <div>
        
        <Sidebar/>
        <br/>   
        <h2 id="title">처리 현황 통계</h2>
    </div>
</template>
<script>
import Sidebar from '../../common/SideBar'
import Data from '../../../data/data'

export default {
    name: "Status",
    components:{
        Sidebar
    }
}
</script>
<style scoped>



    
</style>