<template lang="">
    <div>
        <Sidebar/>
        <br/>   
        <h2>객체종류 시간별 통계</h2>
    </div>
</template>
<script>
import Sidebar from '../../common/SideBar'

export default {
    name: "TimeStatus",
    components:{
        Sidebar
    }
}
</script>
<style lang="">
    
</style>