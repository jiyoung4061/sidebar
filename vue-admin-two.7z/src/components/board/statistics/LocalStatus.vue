<template lang="">
    <div>
        <Sidebar/>
        <br/>   
        <h2>객체종류 지역별 통계</h2>
    </div>
</template>
<script>
import Sidebar from '../../common/SideBar'

export default {
    name: "LocalStatus",
    components:{
        Sidebar
    }
}
</script>
<style lang="">
    
</style>