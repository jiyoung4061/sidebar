<template lang="">
    <div>
        <Sidebar/>
        <br/>   
        <h2>사용자 정보</h2>
    </div>
</template>
<script>
import Sidebar from '../../common/SideBar'

export default {
    name: "UserInfo",
    components:{
        Sidebar
    }
}
</script>
<style lang="">
    
</style>