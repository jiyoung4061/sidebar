<template lang="">
    <div>
        <Sidebar/>
        <br/>   
        <h2>이벤트 로그</h2>
    </div>
</template>
<script>
import Sidebar from '../../common/SideBar'

export default {
    name: "EventLog",
    components:{
        Sidebar
    }
}
</script>
<style lang="">
    
</style>