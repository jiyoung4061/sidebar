<template lang="">
    <div>
        <Sidebar/>
        <br/>   
        <h2>시스템 로그</h2>
    </div>
</template>
<script>
import Sidebar from '../../common/SideBar'

export default {
    name: "SystemLog",
    components:{
        Sidebar
    }
}
</script>
<style lang="">
    
</style>