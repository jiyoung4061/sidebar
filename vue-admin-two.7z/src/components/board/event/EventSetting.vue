<template lang="">
    <div>
        <Sidebar/>
        <br/>   
        <h2>이벤트 설정</h2>
    </div>
</template>
<script>
import Sidebar from '../../common/SideBar'

export default {
    name: "EventSetting",
    components:{
        Sidebar
    }
}
</script>
<style lang="">
    
</style>