<template lang="">
    <div>
        <Sidebar/>
        <br/>   
        <h2>시스템 정보</h2>
    </div>
</template>
<script>
import Sidebar from '../../common/SideBar'

export default {
    name: "SystemInfo",
    components:{
        Sidebar
    }
}
</script>
<style lang="">
    
</style>