<template lang="">
    <div>
        <Sidebar/>
        <br/>
        <h2>CCTV 그룹</h2>
    </div>
</template>
<script>
import Sidebar from '../../common/SideBar'
export default {
    name: "CCTVgroup",
    components:{
        Sidebar
    }
}
</script>
<style lang="">
    
</style> 