<template lang="">
    <div>
        <Sidebar/>
        <br/>
        <h2>집중관제 그룹</h2>
    </div>
</template>
<script>
import Sidebar from '../../common/SideBar'
export default {
    name: "ConcentrationGroup",
    components:{
        Sidebar
    }
}
</script>
<style lang="">
    
</style> 