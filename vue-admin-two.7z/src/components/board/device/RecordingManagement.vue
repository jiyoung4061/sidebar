<template lang="">
    <div>
        <Sidebar/>
        <br/>   
        <h2>녹화장치 정보</h2>
    </div>
</template>
<script>
import Sidebar from '../../common/SideBar'

export default {
    name: "RecordingManagement",
    components:{
        Sidebar
    }
}
</script>
<style lang="">
    
</style>