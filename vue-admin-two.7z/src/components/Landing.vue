<template lang="">
    <div>
        <Sidebar/>
        랜딩페이지
        
    </div>
</template>
<script>

import Sidebar from '../components/common/SideBar'


export default {
    name :'Landing',
    components:{
        Sidebar
    }
}
</script>
<style lang="">
    
</style>