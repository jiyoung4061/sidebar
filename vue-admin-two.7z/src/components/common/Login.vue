<template lang="">
    <div>
        <router-link to="/main"><button id="logout">로그인</button></router-link>
    </div>
</template>
<script>
export default {
    
}
</script>
<style lang="">
    
</style>