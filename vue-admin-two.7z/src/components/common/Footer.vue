<template>
	<footer>
		<h2>MarkAny</h2>
	</footer>
</template>

<script>
export default {
	
}
</script>

<style scoped>
footer{border-top:1px solid #35495e; text-align:center; font-size:16px; color:#41b883; margin:100px 0 0 0;}
</style>